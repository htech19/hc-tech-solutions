# HC Tech — Guia de Películas 2026
## Como adicionar ao seu projeto Lovable

### Passo 1 — Adicione os arquivos ao projeto

No Lovable, use o chat com o seguinte comando:

---
Por favor adicione os seguintes arquivos ao projeto:

1. Crie o arquivo `src/data/peliculas.ts` com o conteúdo do arquivo `peliculas.ts` em anexo
2. Crie o arquivo `src/pages/PeliculasPage.tsx` com o conteúdo do arquivo `PeliculasPage.tsx` em anexo

---

### Passo 2 — Registre a rota (App.tsx ou Router)

Cole no seu arquivo de rotas:

```tsx
import PeliculasPage from "@/pages/PeliculasPage";

// Dentro do seu <Routes>:
<Route path="/peliculas" element={<PeliculasPage />} />
```

### Passo 3 — Adicione link no menu

```tsx
<a href="/peliculas">Guia de Películas</a>
```

### Pronto!
A página já inclui:
- Busca em tempo real (442 modelos)
- Tabela agrupada por marca (clique para expandir)
- Rodapé com contatos HC Tech
- Design responsivo dark/light

### Contatos HC Tech
- Instagram: @hctechinfocell
- Google: https://share.google/V8KzA6lJdjkstlVkz
- E-mail: contato@hctech.com.br

// PeliculasPage.tsx
// Cole este arquivo em src/pages/PeliculasPage.tsx
// Importe peliculas.ts em src/data/peliculas.ts

import { useState, useMemo } from "react";
import { buscarPelicula, getPorMarca, MARCAS, Pelicula } from "@/data/peliculas";

// ── Ícones simples inline (sem dependência extra) ──────────────
const IconSearch = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
  </svg>
);
const IconShield = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
  </svg>
);
const IconX = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 6 6 18M6 6l12 12"/>
  </svg>
);
const IconInstagram = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>
  </svg>
);
const IconGoogle = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
  </svg>
);
const IconMail = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
    <polyline points="22,6 12,13 2,6"/>
  </svg>
);

// ── Marca badge colors ─────────────────────────────────────────
const MARCA_COLORS: Record<string, string> = {
  Apple:    "bg-slate-100 text-slate-700 border-slate-200",
  Samsung:  "bg-blue-50 text-blue-700 border-blue-200",
  Motorola: "bg-indigo-50 text-indigo-700 border-indigo-200",
  Xiaomi:   "bg-orange-50 text-orange-700 border-orange-200",
  Realme:   "bg-yellow-50 text-yellow-700 border-yellow-200",
  Asus:     "bg-teal-50 text-teal-700 border-teal-200",
  Oppo:     "bg-green-50 text-green-700 border-green-200",
  LG:       "bg-red-50 text-red-700 border-red-200",
  Lenovo:   "bg-purple-50 text-purple-700 border-purple-200",
};

// ── Resultado card ─────────────────────────────────────────────
function ResultCard({ item }: { item: Pelicula }) {
  const badgeClass = MARCA_COLORS[item.marca] ?? "bg-gray-100 text-gray-700 border-gray-200";
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-200 p-5 flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <div>
          <span className={`inline-flex items-center text-xs font-semibold px-2.5 py-0.5 rounded-full border ${badgeClass} mb-2`}>
            {item.marca}
          </span>
          <h3 className="text-base font-bold text-gray-900 leading-tight">{item.modelo}</h3>
        </div>
        <IconShield />
      </div>
      {item.compativel_com.length > 0 ? (
        <div>
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2">
            Mesma película serve para:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {item.compativel_com.map((m) => (
              <span key={m} className="text-xs bg-green-50 text-green-700 border border-green-200 rounded-lg px-2.5 py-1 font-medium">
                {m}
              </span>
            ))}
          </div>
        </div>
      ) : (
        <p className="text-xs text-gray-400 italic">Modelo exclusivo — sem compatibilidade cruzada conhecida.</p>
      )}
    </div>
  );
}

// ── Tabela por marca ───────────────────────────────────────────
function TabelaMarca() {
  const [expanded, setExpanded] = useState<string | null>(null);
  const grupos = useMemo(() => getPorMarca(), []);

  return (
    <div className="space-y-3">
      {grupos.map(({ marca, modelos }) => {
        const isOpen = expanded === marca;
        const badgeClass = MARCA_COLORS[marca] ?? "bg-gray-100 text-gray-700 border-gray-200";
        return (
          <div key={marca} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <button
              onClick={() => setExpanded(isOpen ? null : marca)}
              className="w-full flex items-center justify-between px-5 py-4 hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <span className={`inline-flex items-center text-xs font-semibold px-3 py-1 rounded-full border ${badgeClass}`}>
                  {marca}
                </span>
                <span className="text-sm text-gray-500">{modelos.length} modelos</span>
              </div>
              <svg
                className={`w-5 h-5 text-gray-400 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
                fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            {isOpen && (
              <div className="border-t border-gray-100 divide-y divide-gray-50">
                {modelos.map((m) => (
                  <div key={m.id} className="px-5 py-3 flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-4">
                    <span className="text-sm font-semibold text-gray-800 min-w-[180px]">{m.modelo}</span>
                    <span className="text-sm text-gray-500">
                      {m.compativel_com.length > 0
                        ? m.compativel_com.join(" · ")
                        : <span className="italic text-gray-300">—</span>
                      }
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── Página principal ───────────────────────────────────────────
export default function PeliculasPage() {
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState<"busca" | "tabela">("busca");

  const resultados = useMemo(() => {
    if (query.trim().length < 2) return [];
    return buscarPelicula(query);
  }, [query]);

  const showEmpty = query.trim().length >= 2 && resultados.length === 0;

  return (
    <div className="min-h-screen bg-gray-50 font-sans">

      {/* ── HERO ──────────────────────────────────────────────── */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-blue-900 text-white">
        <div className="max-w-3xl mx-auto px-4 pt-12 pb-16 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur border border-white/20 rounded-full px-4 py-1.5 text-xs font-semibold mb-6 text-blue-200">
            <IconShield />
            Guia de Compatibilidade 2026 · 442 modelos
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight mb-3">
            HC Tech <span className="text-blue-400">Películas</span>
          </h1>
          <p className="text-slate-300 text-base sm:text-lg max-w-xl mx-auto">
            Descubra qual película protege o seu celular — e quais outros modelos compartilham o mesmo tamanho.
          </p>
        </div>
      </div>

      {/* ── SEARCH BAR ────────────────────────────────────────── */}
      <div className="max-w-3xl mx-auto px-4 -mt-7">
        <div className="relative bg-white rounded-2xl shadow-lg border border-gray-100">
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
            <IconSearch />
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => { setQuery(e.target.value); setTab("busca"); }}
            placeholder="Digite o modelo do celular… ex: Galaxy A52, iPhone 14, Redmi Note 11"
            className="w-full pl-11 pr-10 py-4 rounded-2xl text-sm text-gray-800 placeholder-gray-400 outline-none bg-transparent"
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
            >
              <IconX />
            </button>
          )}
        </div>
      </div>

      {/* ── TABS ──────────────────────────────────────────────── */}
      <div className="max-w-3xl mx-auto px-4 mt-6">
        <div className="flex gap-2 bg-white rounded-xl border border-gray-100 shadow-sm p-1 w-fit">
          {([
            { key: "busca",  label: "🔍 Buscar modelo" },
            { key: "tabela", label: "📋 Ver por marca"  },
          ] as const).map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all duration-150 ${
                tab === key
                  ? "bg-slate-900 text-white shadow"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* ── CONTENT ───────────────────────────────────────────── */}
      <div className="max-w-3xl mx-auto px-4 mt-6 pb-24">

        {tab === "busca" && (
          <>
            {query.trim().length < 2 && (
              <div className="text-center py-16 text-gray-400">
                <div className="text-5xl mb-4">📱</div>
                <p className="font-medium text-gray-500">Digite pelo menos 2 caracteres para buscar</p>
                <p className="text-sm mt-1">Ex: "samsung a", "iphone 14", "moto g"</p>
              </div>
            )}
            {showEmpty && (
              <div className="text-center py-16 text-gray-400">
                <div className="text-5xl mb-4">🔎</div>
                <p className="font-medium text-gray-500">Nenhum modelo encontrado para "<strong>{query}</strong>"</p>
                <p className="text-sm mt-1">Tente usar apenas parte do nome, ex: "A52" em vez de "Galaxy A52"</p>
              </div>
            )}
            {resultados.length > 0 && (
              <>
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">
                  {resultados.length} resultado{resultados.length > 1 ? "s" : ""} para "{query}"
                </p>
                <div className="grid gap-3">
                  {resultados.map((item) => (
                    <ResultCard key={item.id} item={item} />
                  ))}
                </div>
              </>
            )}
          </>
        )}

        {tab === "tabela" && <TabelaMarca />}
      </div>

      {/* ── FOOTER / CONTATO ──────────────────────────────────── */}
      <footer className="bg-slate-900 text-slate-300 mt-auto">
        <div className="max-w-3xl mx-auto px-4 py-10 flex flex-col items-center gap-6 text-center">
          <div>
            <p className="text-white font-bold text-lg">HC Tech</p>
            <p className="text-slate-400 text-sm mt-1">Especialistas em películas e acessórios para celular</p>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            <a
              href="https://instagram.com/hctechinfocell"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 transition-colors rounded-xl px-4 py-2.5 text-sm font-medium"
            >
              <IconInstagram />
              @hctechinfocell
            </a>
            <a
              href="https://share.google/V8KzA6lJdjkstlVkz"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 transition-colors rounded-xl px-4 py-2.5 text-sm font-medium"
            >
              <IconGoogle />
              Avalie no Google
            </a>
            <a
              href="mailto:contato@hctech.com.br"
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 transition-colors rounded-xl px-4 py-2.5 text-sm font-medium"
            >
              <IconMail />
              contato@hctech.com.br
            </a>
          </div>
          <p className="text-slate-500 text-xs">© 2026 HC Tech · Guia atualizado com 442 modelos</p>
        </div>
      </footer>

    </div>
  );
}
